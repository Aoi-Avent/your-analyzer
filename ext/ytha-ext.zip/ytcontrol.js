'use strict';
// アプリ(履歴アナライザー)から操作される「YouTube再生ウィンドウ」用。
// URLに ytha=1 が付いたタブでのみ動作し、通常のYouTube閲覧には一切干渉しない。
(() => {
  if (!/[?&]ytha=1(&|$)/.test(location.search) || window.__ythaYt) return; window.__ythaYt = true;
  const auto = /[?&]hauto=1(&|$)/.test(location.search); let v = null, last = 0, errSent = '', paused1 = false, blockedSent = false;
  const vid = () => new URLSearchParams(location.search).get('v');
  const ad = () => !!document.querySelector('.html5-video-player.ad-showing');
  const send = m => { try { chrome.runtime.sendMessage(m).catch(() => { }); } catch { } };
  const push = ev => { if (v) send({ type: 'yt-state', ev, id: vid(), t: v.currentTime, dur: isFinite(v.duration) ? v.duration : 0, paused: v.paused, ended: v.ended, ad: ad() }); };
  function bind() {
    const el = document.querySelector('video.html5-main-video') || document.querySelector('video'); if (!el || el === v) return; v = el;
    ['play', 'pause', 'playing', 'waiting', 'loadedmetadata', 'durationchange', 'seeked'].forEach(e => v.addEventListener(e, () => { if (e === 'playing' && !auto && !paused1 && !ad()) { paused1 = true; v.pause(); } push(e); }));
    v.addEventListener('ended', () => push('ended'));
    v.addEventListener('timeupdate', () => { const n = Date.now(); if (n - last > 400) { last = n; push('time'); } });
    if (auto) { const p = v.play(); if (p && p.catch) p.catch(() => { if (!blockedSent) { blockedSent = true; push('blocked'); } }); }
  }
  setInterval(() => {
    bind(); const id = vid(), e = document.querySelector('.html5-video-player .ytp-error');
    if (id && e && errSent !== id && getComputedStyle(e).display !== 'none') { errSent = id; send({ type: 'yt-state', ev: 'error', id }); }
  }, 600);
  // 没入表示(再生画面だけを全面表示): YouTubeの画面構造に依存するベストエフォート
  const IMM = 'ytd-masthead,#masthead-container,#secondary,#below,#comments,#related,ytd-watch-metadata,tp-yt-app-drawer,#guide,ytd-mini-guide-renderer{display:none!important}ytd-app{--ytd-masthead-height:0px!important}#page-manager{margin-top:0!important}ytd-watch-flexy[theater] #player-theater-container,ytd-watch-flexy #player-container-outer,#player-container,#player,ytd-player,#movie_player{position:fixed!important;inset:0!important;width:100vw!important;height:100vh!important;max-width:none!important;max-height:none!important;z-index:2147483000!important;background:#000!important}#movie_player video{width:100%!important;height:100%!important;left:0!important;top:0!important;object-fit:contain}html,body{overflow:hidden!important}';
  function immersive(on) { let st = document.getElementById('ytha-imm'); if (on && !st) { st = document.createElement('style'); st.id = 'ytha-imm'; st.textContent = IMM; document.head.appendChild(st); } else if (!on && st) st.remove(); window.dispatchEvent(new Event('resize')); }
  if (/[?&]himm=1(&|$)/.test(location.search)) immersive(true);
  addEventListener('keydown', e => { if (e.key === 'Escape') send({ type: 'yt-state', ev: 'esc', id: vid() }); });
  chrome.runtime.onMessage.addListener((m, _s, reply) => {
    if (m.type !== 'yt-cmd') return;
    try {
      if (m.cmd === 'ping') return reply({ ok: true, id: vid() }); if (m.cmd === 'immersive') return immersive(!!m.a); if (!v) return;
      if (m.cmd === 'play') { const p = v.play(); if (p && p.catch) p.catch(() => push('blocked')); }
      else if (m.cmd === 'pause') v.pause(); else if (m.cmd === 'seek') v.currentTime = Math.max(0, +m.a || 0);
      else if (m.cmd === 'vol') v.volume = Math.min(1, Math.max(0, m.a / 100)); else if (m.cmd === 'rate') v.playbackRate = +m.a || 1;
    } catch { }
  });
})();
