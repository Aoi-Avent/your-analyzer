'use strict';
// YouTubeの再生リストページ(高評価=LL / 後で見る=WL / 自作リスト)から動画一覧を読み取り、履歴アナライザーへ取り込む。
(() => {
  if (window.__ythaList) return; window.__ythaList = true;
  if (/[?&]ytha=1(&|$)/.test(location.search)) return;   // 再生ウィンドウでは動作しない
  const sleep = ms => new Promise(r => setTimeout(r, ms)), clean = s => (s || '').replace(/\s+/g, ' ').trim();
  const toSec = s => { const m = (s || '').match(/(?:(\d+):)?(\d{1,2}):(\d{2})/); return m ? (+m[1] || 0) * 3600 + +m[2] * 60 + +m[3] : null; };
  const listId = () => new URLSearchParams(location.search).get('list');
  const ping = m => { try { chrome.runtime.sendMessage(m).catch(() => { }); } catch { } };
  function items() {
    const out = new Map();
    document.querySelectorAll('a[href*="/watch?v="]').forEach(a => {
      const h = a.getAttribute('href') || '', m = h.match(/[?&]v=([\w-]{11})/); if (!m || !/[?&]list=/.test(h)) return;
      const id = m[1], box = a.closest('ytd-playlist-video-renderer, ytd-playlist-panel-video-renderer, yt-lockup-view-model, ytd-video-renderer') || a.parentElement, cur = out.get(id) || { id, title: '', ch: '', chid: '', dur: null };
      const vt = box && box.querySelector('#video-title'), t = clean(a.getAttribute('title') || (a.id === 'video-title' ? a.textContent : '') || (vt && (vt.getAttribute('title') || vt.textContent)));
      if (t && t.length > cur.title.length) cur.title = t;
      if (box) {
        const c = box.querySelector('a[href^="/@"], a[href*="/channel/"], a[href*="/c/"]'); if (c && !cur.ch) { cur.ch = clean(c.textContent); cur.chid = (c.getAttribute('href') || '').split('?')[0].split('/').pop(); }
        const d = box.querySelector('ytd-thumbnail-overlay-time-status-renderer, badge-shape, .badge-shape-wiz__text, yt-thumbnail-badge-view-model'); if (cur.dur == null && d) cur.dur = toSec(d.textContent);
      }
      out.set(id, cur);
    });
    return [...out.values()];
  }
  async function scrape({ maxSec = 300, maxItems = 8000 } = {}) {
    const t0 = Date.now(); let last = -1, stale = 0;
    for (; ;) {
      const n = items().length; ping({ type: 'progress', n }); stale = n === last ? stale + 1 : 0; last = n;
      if (stale >= 6 || n >= maxItems || (Date.now() - t0) / 1000 > maxSec) break;
      window.scrollTo(0, document.documentElement.scrollHeight); const els = document.querySelectorAll('ytd-playlist-video-renderer'); if (els.length) els[els.length - 1].scrollIntoView({ block: 'end' }); await sleep(800);
    }
    const h = document.querySelector('ytd-playlist-header-renderer h1, yt-dynamic-text-view-model h1, h1'), name = clean(h && h.textContent) || clean(document.title.replace(/\s*-\s*YouTube$/, ''));
    return { ok: true, listId: listId(), name, items: items() };
  }
  function index() {
    const m = new Map();
    document.querySelectorAll('a[href*="/playlist?list="]').forEach(a => {
      const id = new URLSearchParams((a.getAttribute('href') || '').split('?')[1] || '').get('list'); if (!id || id === 'LL' || id === 'WL' || /^RD/.test(id)) return;
      const nm = clean(a.getAttribute('title') || a.getAttribute('aria-label') || (a.closest('ytd-grid-playlist-renderer, yt-lockup-view-model, ytd-playlist-renderer') || a).textContent).slice(0, 80); const cur = m.get(id);
      if (!cur || (nm && nm.length < cur.name.length && nm.length > 1)) m.set(id, { id, name: cur && !nm ? cur.name : nm });
    });
    return [...m.values()];
  }
  chrome.runtime.onMessage.addListener((m, _s, reply) => {
    if (m.type === 'ping') { reply({ ok: true }); return; }
    if (m.type === 'coll-scrape') { scrape(m).then(reply).catch(e => reply({ ok: false, error: String(e && e.message || e) })); return true; }
    if (m.type === 'coll-index') { reply({ ok: true, lists: index() }); return; }
  });
  // 再生リストページに取り込みパネルを表示(YouTubeはSPAなので画面遷移を監視)
  let box = null;
  function panel() {
    const on = location.pathname === '/playlist' && listId();
    if (!on) { if (box) { box.remove(); box = null; } return; } if (box) return;
    box = document.createElement('div'); box.style.cssText = 'position:fixed;right:16px;bottom:16px;z-index:99999;background:#fff;color:#111;border:1px solid #ccc;border-radius:10px;padding:10px 12px;font:13px system-ui;box-shadow:0 2px 10px rgba(0,0,0,.25)';
    box.innerHTML = '<b style="color:#e5322d">▶ 履歴アナライザー</b><br><button id="yl-b">このリストを取り込む(最後まで自動スクロール)</button><div id="yl-s" style="margin-top:4px;color:#666"></div>'; document.body.appendChild(box);
    box.querySelector('#yl-b').onclick = async () => {
      const st = box.querySelector('#yl-s'), tm = setInterval(() => { st.textContent = `読み込み中… ${items().length}本`; }, 800);
      try { const r = await scrape(), id = r.listId; if (!r.items.length) throw new Error('動画を検出できませんでした');
        const res = await chrome.runtime.sendMessage({ type: 'coll-ingest', coll: { id: id === 'LL' || id === 'WL' ? id : 'PL:' + id, name: id === 'LL' ? '高評価した動画' : id === 'WL' ? '後で見る' : r.name, kind: id === 'LL' ? 'liked' : id === 'WL' ? 'later' : 'custom', items: r.items, src: 'scrape' } });
        clearInterval(tm); st.textContent = res && res.ok ? `完了: ${r.items.length}本を取り込みました` : 'エラー: ' + (res && res.error);
      } catch (e) { clearInterval(tm); st.textContent = 'エラー: ' + e.message; }
    };
  }
  document.addEventListener('yt-navigate-finish', panel); panel();
})();
