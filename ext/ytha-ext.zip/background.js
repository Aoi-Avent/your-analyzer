'use strict';
importScripts('sync.js');
const idb = () => new Promise((res, rej) => { const r = indexedDB.open('ytha', 3); r.onupgradeneeded = () => { const d = r.result;[['acts', 'k'], ['files', 'name'], ['vmeta', 'id'], ['lists', 'id'], ['coll', 'id'], ['lyrics', 'id']].forEach(([n, k]) => { if (!d.objectStoreNames.contains(n)) d.createObjectStore(n, { keyPath: k }); }); }; r.onsuccess = () => res(r.result); r.onerror = () => rej(r.error); });
const tx = async (st, mode, fn) => { const db = await idb(); return new Promise((res, rej) => { const t = db.transaction(st, mode); let o; try { o = fn(t.objectStore(st)); } catch (e) { rej(e); return; } t.oncomplete = () => res(o && 'result' in o ? o.result : undefined); t.onerror = () => rej(t.error); t.onabort = () => rej(t.error || new Error('abort')); }); };
const sleep = ms => new Promise(r => setTimeout(r, ms));
const tell = m => chrome.runtime.sendMessage(m).catch(() => { });

// アプリ画面を開く(開いていれば前面へ)
chrome.action.onClicked.addListener(async () => {
  const url = chrome.runtime.getURL('app.html'); const [t] = await chrome.tabs.query({ url });
  if (t) { await chrome.tabs.update(t.id, { active: true }); await chrome.windows.update(t.windowId, { focused: true }); } else chrome.tabs.create({ url });
});
// 復習の件数をツールバーアイコンのバッジに表示
async function badge() {
  try { const all = await tx('vmeta', 'readonly', s => s.getAll()), today = new Date().toLocaleDateString('sv-SE'); const n = (all || []).filter(m => m.rv && m.rv.due <= today).length; await chrome.action.setBadgeText({ text: n ? String(n) : '' }); await chrome.action.setBadgeBackgroundColor({ color: '#e5322d' }); } catch { }
}
chrome.alarms.create('badge', { periodInMinutes: 60 }); chrome.alarms.onAlarm.addListener(a => { if (a.name === 'badge') badge(); });
chrome.runtime.onInstalled.addListener(badge); chrome.runtime.onStartup.addListener(badge); badge();

async function store(rows, label) {
  const before = await tx('acts', 'readonly', s => s.count());
  for (let i = 0; i < rows.length; i += 3000) await tx('acts', 'readwrite', s => { rows.slice(i, i + 3000).forEach(r => s.put(r)); });
  const after = await tx('acts', 'readonly', s => s.count()), ds = rows.map(r => r.d).sort();
  await tx('files', 'readwrite', s => { s.put({ name: `${label} ${new Date().toLocaleString('ja-JP')}`, n: rows.length, from: ds[0], to: ds[ds.length - 1], skipped: 0, prod: {}, at: Date.now() }); });
  tell({ type: 'synced' }); return { added: after - before };
}
async function waitComplete(id, ms) { const t0 = Date.now(); while (Date.now() - t0 < ms) { const t = await chrome.tabs.get(id); if (t.status === 'complete') return; await sleep(300); } throw new Error('ページの読み込みがタイムアウトしました'); }
async function ready(id) { for (let i = 0; i < 30; i++) { try { const r = await chrome.tabs.sendMessage(id, { type: 'ping' }); if (r && r.ok) return; } catch { } await sleep(500); } throw new Error('マイアクティビティ画面と通信できません(ログイン状態を確認してください)'); }
async function doSync({ since, days }, appTab) {
  let min = '', until = null;
  if (since) { min = '&min=' + new Date(since + 'T00:00:00').getTime() * 1000; until = since.replace(/-/g, ''); }
  else if (days) { const d = new Date(); d.setDate(d.getDate() - days); d.setHours(0, 0, 0, 0); min = '&min=' + d.getTime() * 1000; until = d.toLocaleDateString('sv-SE').replace(/-/g, ''); }
  const tab = await chrome.tabs.create({ url: `https://myactivity.google.com/myactivity?hl=ja&product=26${min}`, active: true });
  try {
    await waitComplete(tab.id, 60000); const t = await chrome.tabs.get(tab.id);
    if (!/^https:\/\/myactivity\.google\.com\//.test(t.url || '')) throw new Error('Googleにログインしていないようです。ログイン後にもう一度お試しください。');
    await ready(tab.id);
    const r = await chrome.tabs.sendMessage(tab.id, { type: 'scrape', maxSec: 600, untilDate: until });
    if (!r || !r.ok) throw new Error(r && r.error || '履歴を取得できませんでした');
    if (!r.rows.length) throw new Error(`履歴が見つかりません(カード${r.diag.cards}件)。Googleの画面構造が変わった可能性があります。`);
    const s = await store(r.rows, '[同期]'); return { ok: true, n: r.rows.length, ...s };
  } finally { chrome.tabs.remove(tab.id).catch(() => { }); if (appTab) chrome.tabs.update(appTab, { active: true }).catch(() => { }); }
}
// ---- YouTubeの再生リスト(高評価/後で見る/自作リスト)の取り込み ----
async function putColl(c) { const prev = await tx('coll', 'readonly', s => s.get(c.id)), rec = YS.mergeColl(prev, c, new Date().toLocaleDateString('sv-SE')); await tx('coll', 'readwrite', s => { s.put(rec); }); tell({ type: 'synced' }); return rec.items.length; }
async function withTab(url, fn, appTab) {
  const tab = await chrome.tabs.create({ url, active: true });
  try { await waitComplete(tab.id, 60000); const t = await chrome.tabs.get(tab.id); if (!/^https:\/\/www\.youtube\.com\//.test(t.url || '')) throw new Error('YouTubeにログインしていないようです'); await ready(tab.id); return await fn(tab.id); }
  finally { chrome.tabs.remove(tab.id).catch(() => { }); if (appTab) chrome.tabs.update(appTab, { active: true }).catch(() => { }); }
}
async function collSync(lists, appTab) {
  const res = [], errs = [];
  for (const L of lists) {
    try {
      const r = await withTab(`https://www.youtube.com/playlist?list=${L.id}&hl=ja`, id => chrome.tabs.sendMessage(id, { type: 'coll-scrape', maxSec: 300 }), appTab);
      if (!r || !r.ok) throw new Error(r && r.error || '取得できませんでした'); if (!r.items.length) throw new Error('動画を検出できませんでした(空のリスト、またはYouTubeの画面構造の変更)');
      const n = await putColl({ id: L.id === 'LL' || L.id === 'WL' ? L.id : 'PL:' + L.id, name: L.name || r.name, kind: L.kind || 'custom', items: r.items, src: 'scrape' }); res.push({ id: L.id, n });
    } catch (e) { errs.push(`${L.name || L.id}: ${e.message}`); }
  }
  return { ok: true, res, errs };
}
chrome.runtime.onMessage.addListener((msg, sender, send) => {
  if (msg.type === 'coll-ingest') { putColl(msg.coll).then(n => send({ ok: true, n })).catch(e => send({ ok: false, error: String(e) })); return true; }
  if (msg.type === 'coll-sync') { collSync(msg.lists || [], sender.tab && sender.tab.id).then(send).catch(e => send({ ok: false, error: String(e) })); return true; }
  if (msg.type === 'coll-index') { withTab('https://www.youtube.com/feed/playlists?hl=ja', id => chrome.tabs.sendMessage(id, { type: 'coll-index' }), sender.tab && sender.tab.id).then(send).catch(e => send({ ok: false, error: e.message || String(e) })); return true; }
  return false;
});
chrome.runtime.onMessage.addListener((msg, sender, send) => {
  if (msg.type === 'sync') { doSync(msg, sender.tab && sender.tab.id).then(send).catch(e => send({ ok: false, error: e.message || String(e) })); return true; }
  if (msg.type === 'ingest-rows') { store(msg.rows || [], '[手動取込]').then(r => send({ ok: true, ...r })).catch(e => send({ ok: false, error: String(e) })); return true; }
  if (msg.type === 'badge') { badge(); return; }
  if (msg.type === 'progress') tell({ type: 'sync-progress', n: msg.n });
});
