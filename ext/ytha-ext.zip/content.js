'use strict';
// Googleマイアクティビティ(YouTube)の画面上で、履歴を自動スクロール→取得する。
(() => {
  if (window.__ythaLoaded) return; window.__ythaLoaded = true;
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const cards = () => document.querySelectorAll('[role=listitem]');
  const ping = m => { try { chrome.runtime.sendMessage(m).catch(() => { }); } catch { } };
  async function scrape({ maxSec = 600, maxCards = 40000, untilDate = null } = {}) {
    const t0 = Date.now(); let last = -1, stale = 0;
    for (; ;) {
      const c = cards(), n = c.length; ping({ type: 'progress', n });
      stale = n === last ? stale + 1 : 0; last = n;
      if (stale >= 8 || n >= maxCards || (Date.now() - t0) / 1000 > maxSec) break;
      if (untilDate) { const ds = [...document.querySelectorAll('[data-date]')].map(x => x.getAttribute('data-date')).filter(d => /^\d{8}$/.test(d)); if (ds.length && ds.reduce((a, b) => a < b ? a : b) < untilDate) break; }
      if (c[n - 1]) c[n - 1].scrollIntoView({ block: 'end' }); window.scrollTo(0, document.documentElement.scrollHeight); await sleep(700);
    }
    const { rows, diag } = extractFromDoc(document); return { ok: true, rows, diag };
  }
  chrome.runtime.onMessage.addListener((msg, _s, send) => {
    if (msg.type === 'ping') { send({ ok: true }); return; }
    if (msg.type === 'scrape') { scrape(msg).then(send).catch(e => send({ ok: false, error: String(e && e.message || e) })); return true; }
  });
  // 手動取り込みパネル
  if (!/\/myactivity/.test(location.pathname)) return;
  const box = document.createElement('div');
  box.style.cssText = 'position:fixed;right:16px;bottom:16px;z-index:99999;background:#fff;color:#111;border:1px solid #ccc;border-radius:10px;padding:10px 12px;font:13px system-ui;box-shadow:0 2px 10px rgba(0,0,0,.25)';
  box.innerHTML = '<b style="color:#e5322d">▶ 履歴アナライザー</b><br><select id="yt-r"><option value="0">表示中の分だけ</option><option value="30">過去30日</option><option value="90">過去90日</option><option value="365">過去1年</option><option value="9999">できるだけ全部</option></select> <button id="yt-b">取り込む</button><div id="yt-s" style="margin-top:4px;color:#666"></div>';
  document.body.appendChild(box); const st = box.querySelector('#yt-s');
  box.querySelector('#yt-b').onclick = async () => {
    const days = +box.querySelector('#yt-r').value; let until = null;
    if (days && days < 9999) { const d = new Date(); d.setDate(d.getDate() - days); until = d.toLocaleDateString('sv-SE').replace(/-/g, ''); }
    st.textContent = '取得中…'; const t = setInterval(() => { st.textContent = `取得中… ${cards().length}件`; }, 800);
    try {
      const r = days === 0 ? (() => { const x = extractFromDoc(document); return { ok: true, ...x }; })() : await scrape({ untilDate: days === 9999 ? null : until });
      const res = await chrome.runtime.sendMessage({ type: 'ingest-rows', rows: r.rows }); clearInterval(t);
      st.textContent = res && res.ok ? `完了: ${r.rows.length}件取得 / 新規${res.added}件` : 'エラー: ' + (res && res.error);
    } catch (e) { clearInterval(t); st.textContent = 'エラー: ' + e.message; }
  };
})();
