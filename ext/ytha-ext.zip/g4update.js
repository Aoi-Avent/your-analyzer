'use strict';
/* ===== 個人配布(開発者モード)用: ワンクリック自己更新 =====
   ※Chromeウェブストア提出版には含めません(ストアは自動更新・外部コードの取得は禁止のため)。
   仕組み: 更新サイトの ext/latest.json を確認 → zipを取得してSHA-256検証 → 展開 → 拡張機能フォルダへ上書き → 拡張機能を再読み込み */
const YU = {
  async inflateRaw(u8) { return new Uint8Array(await new Response(new Blob([u8]).stream().pipeThrough(new DecompressionStream('deflate-raw'))).arrayBuffer()); },
  async unzip(buf) {
    const u = new Uint8Array(buf), dv = new DataView(u.buffer, u.byteOffset, u.byteLength); let e = -1;
    for (let i = u.length - 22; i >= Math.max(0, u.length - 65557); i--) if (dv.getUint32(i, true) === 0x06054b50) { e = i; break; }
    if (e < 0) throw new Error('zipとして読めません'); const n = dv.getUint16(e + 10, true); let p = dv.getUint32(e + 16, true); const out = [];
    for (let k = 0; k < n; k++) {
      if (dv.getUint32(p, true) !== 0x02014b50) throw new Error('zipが壊れています');
      const method = dv.getUint16(p + 10, true), csz = dv.getUint32(p + 20, true), nl = dv.getUint16(p + 28, true), el = dv.getUint16(p + 30, true), cl = dv.getUint16(p + 32, true), off = dv.getUint32(p + 42, true), name = new TextDecoder().decode(u.subarray(p + 46, p + 46 + nl));
      p += 46 + nl + el + cl; if (name.endsWith('/')) continue;
      const lnl = dv.getUint16(off + 26, true), lel = dv.getUint16(off + 28, true), ds = off + 30 + lnl + lel, raw = u.subarray(ds, ds + csz);
      if (method !== 0 && method !== 8) throw new Error('未対応の圧縮方式'); out.push({ name, data: method === 0 ? raw.slice() : await YU.inflateRaw(raw) });
    }
    return out;
  },
  safe: n => /^[A-Za-z0-9][\w.-]*\.(js|css|html|json|png)$/.test(n),   // ルート直下・許可した拡張子のみ
  async sha256(buf) { return [...new Uint8Array(await crypto.subtle.digest('SHA-256', buf))].map(b => b.toString(16).padStart(2, '0')).join(''); },
  cmp(a, b) { const x = a.split('.').map(Number), y = b.split('.').map(Number); for (let i = 0; i < 3; i++) if ((x[i] || 0) !== (y[i] || 0)) return (x[i] || 0) - (y[i] || 0); return 0; },
  async write(dir, name, data) { const w = await (await dir.getFileHandle(name, { create: true })).createWritable(); await w.write(data); await w.close(); },
  // 検証済みのzipを展開して、フォルダへ書き込む(manifest.json は最後)
  async apply(dir, zipBuf, expect) {
    const files = await YU.unzip(zipBuf), bad = files.find(f => !YU.safe(f.name)); if (bad) throw new Error('不正なファイル名が含まれています: ' + bad.name);
    const mf = files.find(f => f.name === 'manifest.json'); if (!mf) throw new Error('manifest.json がありません'); const m = JSON.parse(new TextDecoder().decode(mf.data));
    if (m.name !== expect.name) throw new Error('別の拡張機能のzipです'); if (expect.version && m.version !== expect.version) throw new Error('バージョンが一致しません');
    for (const f of files.filter(f => f.name !== 'manifest.json')) await YU.write(dir, f.name, f.data); await YU.write(dir, 'manifest.json', mf.data); return files.length;
  }
};
G2.ucur = () => { try { return chrome.runtime.getManifest(); } catch { return { name: '', version: '0' }; } };
G2.extUpdCard = () => {
  const m = G2.ucur(), u = ls.get('ytha.upd', null);
  if (m.update_url) return `<p class="sub">バージョン: <b>${esc(m.version)}</b>。Chromeウェブストア版は自動で更新されます。</p>`;
  const newer = u && u.latest && YU.cmp(u.latest.version, m.version) > 0;
  return `<p class="sub">バージョン: <b>${esc(m.version)}</b>${u ? ` ／ 最新: <b>${esc(u.latest.version)}</b>(${G2.ago(u.at)}に確認)${newer ? ' <b class="up">更新があります</b>' : ' ✔ 最新です'}` : ''}</p>
<div class="rb">更新サイトのURL <input data-g="ubase" value="${esc(G2.cfg.updBase || '')}" placeholder="https://…(スマホ用Webアプリと同じURL)" size="34"><button data-g="ucheck">更新を確認</button></div>${u && u.latest.notes ? `<p class="sub">${esc(u.latest.notes)}</p>` : ''}
<div class="rb"><button data-g="udir">${G2.udirOk ? '拡張機能フォルダ: 設定済み(変更)' : '拡張機能フォルダを選択(初回のみ)'}</button><button class="pri" data-g="urun" ${newer ? '' : 'disabled'}>今すぐ更新</button></div>
<p class="sub">「拡張機能フォルダ」は <code>chrome://extensions</code> の詳細に表示される「ソース」のフォルダです。初回だけ選ぶと、以降はボタン1つで更新・再読み込みされます。</p>`;
};
G2.chg.ubase = t => { G2.cfg.updBase = t.value.trim(); G2.saveCfg(); };
sget('extdir').then(h => { G2.udirOk = !!h; }).catch(() => { });
G2.acts.ucheck = async () => {
  const base = (G2.cfg.updBase || '').replace(/\/+$/, ''); if (!/^https:\/\//.test(base)) return toast('更新サイトのURL(https://…)を入力してください');
  try { const r = await fetch(base + '/ext/latest.json', { cache: 'no-store' }); if (!r.ok) throw new Error('取得できません(' + r.status + ')'); const j = await r.json(); if (!j.version || !j.file) throw new Error('latest.json の形式が不正です'); ls.set('ytha.upd', { latest: j, at: Date.now() }); render(); toast(YU.cmp(j.version, G2.ucur().version) > 0 ? `新しいバージョン ${j.version} があります` : '最新版です'); }
  catch (e) { err(e, '更新確認'); }
};
G2.acts.udir = async () => {
  try { const h = await showDirectoryPicker({ id: 'ytha-ext', mode: 'readwrite' }); let m; try { m = JSON.parse(await (await (await h.getFileHandle('manifest.json')).getFile()).text()); } catch { throw new Error('このフォルダに manifest.json がありません。拡張機能のフォルダを選んでください'); } if (m.name !== G2.ucur().name) throw new Error('別の拡張機能のフォルダです'); G2._extdir = h; await sset('extdir', h).catch(() => { }); G2.udirOk = true; render(); toast('拡張機能フォルダを設定しました'); }
  catch (e) { if (e.name !== 'AbortError') err(e, 'フォルダ選択'); }
};
G2.acts.urun = async () => {
  const u = ls.get('ytha.upd'), base = (G2.cfg.updBase || '').replace(/\/+$/, ''); if (!u) return; const h = G2._extdir || await sget('extdir'); if (!h) return toast('先に拡張機能フォルダを選択してください');
  try {
    if ((await h.queryPermission({ mode: 'readwrite' })) !== 'granted' && (await h.requestPermission({ mode: 'readwrite' })) !== 'granted') throw new Error('フォルダへの書き込みが許可されませんでした');
    busy('更新をダウンロード中…', .3); const r = await fetch(base + '/ext/' + u.latest.file, { cache: 'no-store' }); if (!r.ok) throw new Error('zipを取得できません(' + r.status + ')'); const buf = await r.arrayBuffer();
    if (u.latest.sha256 && (await YU.sha256(buf)) !== u.latest.sha256) throw new Error('ファイルの検証(SHA-256)に失敗しました。更新を中止します');
    busy('適用中…', .7); const n = await YU.apply(h, buf, { name: G2.ucur().name, version: u.latest.version }); busy(''); toast(`${n}ファイルを更新しました。再読み込みします…`); setTimeout(() => chrome.runtime.reload(), 900);
  } catch (e) { busy(''); err(e, '更新'); }
};
if (typeof module !== 'undefined') module.exports = { YU };
